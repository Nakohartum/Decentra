﻿using UnityEngine;

namespace _Root.Code.PoliceFeature
{
    public class PoliceView : MonoBehaviour
    {
        [field: SerializeField] public Rigidbody2D Rigidbody2D { get; private set; }
    }
}