﻿using _Root.Code.CarFeature;
using _Root.Code.GameLoseWinFeature;
using _Root.Code.HackFeature;
using _Root.Code.InputFeature;
using _Root.Code.LevelFeature;
using _Root.Code.Player;
using _Root.Code.PoliceFeature;
using _Root.Code.UpdateFeature;
using Cinemachine;
using Player;
using UnityEngine;

namespace _Root.Code
{
    public class InitializeManager
    {
        private readonly CarSO _carSo;
        private readonly LevelView _levelPrefab;
        private readonly UpdateManager _updateManager;
        private readonly LevelFactory _levelFactory;
        private CinemachineTargetGroup _cinemachineTargetGroup;
        private PoliceSO _policeSo;
        private PlayerSO _playerSo;
        private InputView _inputView;
        private LoseWinView _loseWinView;

        public InitializeManager(CarSO carSo, UpdateManager updateManager, 
            CinemachineTargetGroup cinemachineTargetGroup, LevelView levelPrefab, PoliceSO policeSo, PlayerSO playerSo, InputView inputView, LoseWinView loseWinView)
        {
            _carSo = carSo;
            _updateManager = updateManager;
            _cinemachineTargetGroup = cinemachineTargetGroup;
            _levelPrefab = levelPrefab;
            _policeSo = policeSo;
            _playerSo = playerSo;
            _inputView = inputView;
            _loseWinView = loseWinView;
        }

        public void Initialize()
        {
            var inputController = new InputController(_inputView);
            inputController.HideHackControllers();
            inputController.ShowPlayerControllers();
            _loseWinView.gameObject.SetActive(false);
            _updateManager.AddUpdatable(inputController);
            var levelFactory = new LevelFactory(_levelPrefab);
            var level = levelFactory.CreateLevel();
            level.WinTrigger.OnWin.AddListener(() =>
            {
                _loseWinView.gameObject.SetActive(true);
                _loseWinView.HideLoseScreen();
                _loseWinView.ShowWinScreen();
                _updateManager.SetGameStatus(GameStatus.GameEnded);
            });
            var playerFactory = new PlayerFactory(_playerSo, level.SpawnPosition, inputController);
            var playerPresenter = playerFactory.CreatePlayer();
            _updateManager.AddFixedUpdatable(playerPresenter);
            var carFactory = new CarFactory(inputController, _cinemachineTargetGroup);
            var carPresenter = carFactory.CreateCar(_carSo, level.SpawnPosition.position, level.SpawnPosition.rotation);
            _updateManager.AddFixedUpdatable(carPresenter);
            var policeFactory = new PoliceFactory(_policeSo);
            var hackFactory = new HackFactory(_inputView);
            carPresenter.OnEnteredVehicle.AddListener(() =>
            {
                var policePresenter = policeFactory.CreatePoliceUnit(carPresenter.CarView.Rigidbody);
                _updateManager.AddUpdatable(policePresenter);
            });
            inputController.OnActionButtonPressed.AddListener((_) =>
            {
                inputController.HidePlayerControllers();
                var hackPresenter = hackFactory.CreateHackPresenter();
                inputController.ShowHackControllers();
                hackPresenter.OnMiniGameFinished.AddListener(() =>
                {
                    inputController.HidePlayerControllers();
                    inputController.HideHackControllers();
                    playerPresenter.EnterCar(true);
                });
                _updateManager.AddUpdatable(hackPresenter);
            });
        }
    }
}