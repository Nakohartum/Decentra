﻿namespace _Root.Code.InputFeature
{
    public static class InputStrings
    {
        public static string HORIZONTAL = "Horizontal";
        public static string VERTICAL = "Vertical";
        public static string ACTION = "Action";
    }
}