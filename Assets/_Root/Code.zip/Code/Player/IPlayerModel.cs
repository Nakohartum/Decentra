﻿namespace _Root.Code.Player
{
    public interface IPlayerModel 
    {
        float Speed { get; }
    }
}