﻿namespace _Root.Code.UpdateFeature
{
    public enum GameStatus
    {
        GameEnded,
        GameInProgress,
    }
}