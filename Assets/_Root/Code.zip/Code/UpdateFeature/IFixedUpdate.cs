﻿using System;

namespace _Root.Code.UpdateFeature
{
    public interface IFixedUpdate : IDisposable
    {
        void FixedUpdate();   
    }
}