﻿namespace _Root.Code
{
    public static class GameSettings
    {
        public static int DAMAGE = 15;
    }
}