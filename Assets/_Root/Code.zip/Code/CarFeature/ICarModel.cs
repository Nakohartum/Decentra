﻿namespace _Root.Code.CarFeature
{
    public interface ICarModel
    {
        float Speed { get; }
        float Health { get; }
        float Acceleration { get; }
        float TurnSpeed { get; }
        float SideFriction { get;}
    }
}